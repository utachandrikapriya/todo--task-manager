
# To-Do Task Manager

Minimal project to demonstrate clean architecture and system design.

## Run
cd backend
npm install
node src/app.js
