
async function addTask(){
  const title=document.getElementById("task").value;
  await fetch("http://localhost:3000/tasks",{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({title})
  });
  loadTasks();
}
async function loadTasks(){
  const res=await fetch("http://localhost:3000/tasks");
  const tasks=await res.json();
  document.getElementById("list").innerHTML =
    tasks.map(t=>`<li>${t.title} - ${t.status}</li>`).join("");
}
loadTasks();
