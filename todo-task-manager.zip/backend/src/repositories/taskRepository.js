
const tasks = [];
module.exports = {
  getAll: () => tasks,
  add: (task) => tasks.push(task),
  updateStatus: (id) => {
    const t = tasks.find(x => x.id === id);
    if (t) t.status = "COMPLETED";
    return t;
  }
};
