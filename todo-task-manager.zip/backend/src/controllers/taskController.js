
const service = require("../services/taskService");

exports.createTask = (req, res) => {
  const task = service.createTask(req.body.title, req.body.priority);
  res.json(task);
};
exports.getTasks = (req, res) => res.json(service.getTasks());
exports.completeTask = (req, res) =>
  res.json(service.completeTask(Number(req.params.id)));
