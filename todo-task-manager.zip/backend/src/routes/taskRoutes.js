
const express = require("express");
const controller = require("../controllers/taskController");
const router = express.Router();

router.post("/", controller.createTask);
router.get("/", controller.getTasks);
router.put("/:id", controller.completeTask);

module.exports = router;
