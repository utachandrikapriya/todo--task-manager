
class Task {
  constructor(id, title, priority = "MEDIUM") {
    this.id = id;
    this.title = title;
    this.priority = priority;
    this.status = "PENDING";
    this.createdAt = new Date();
  }
}
module.exports = Task;
