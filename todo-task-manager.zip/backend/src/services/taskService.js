
const Task = require("../models/task");
const repo = require("../repositories/taskRepository");

module.exports = {
  createTask: (title, priority) => {
    const task = new Task(Date.now(), title, priority);
    repo.add(task);
    return task;
  },
  getTasks: () => repo.getAll(),
  completeTask: (id) => repo.updateStatus(id)
};
